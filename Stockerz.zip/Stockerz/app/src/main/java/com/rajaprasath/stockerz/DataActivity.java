package com.rajaprasath.stockerz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.StorageReference;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import data.Databasehandler;
import model.Stocks;
import utils.Utils;

public class DataActivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private FirebaseUser user;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private StorageReference storageReference;
    private Spinner mspinner;
    private Databasehandler controller;
    private List<Stocks> myList;
    private CollectionReference collectionReference = db.collection("Journal");
    private TextView date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        date=findViewById(R.id.date);
        mspinner = findViewById(R.id.spinner);
        String[] moptions = {"RELIANCE", "TATA STEEL", "CIPLA", "EICHERMOT", "ASHOKLEY", "BSE(SENSEX)", "NIFTY(NIFTY)"};
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, moptions);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mspinner.setAdapter(aa);
        controller = new Databasehandler(getApplicationContext());
        SQLiteDatabase db = controller.getWritableDatabase();

        db.execSQL("delete from " + Utils.Table_name);


        BufferedReader buffer = null;
        try {
            buffer = new BufferedReader(
                    new InputStreamReader(DataActivity.this.getAssets().open("RELIANCE.NS.csv"), "UTF-8"));

            // do reading, usually loop until end of file reading
            String mLine;
            while ((mLine = buffer.readLine()) != null) {
                //process line

            }
        } catch (IOException e) {
            //log the exception
        } finally {
            if (buffer != null) {
                try {
                    buffer.close();
                } catch (IOException e) {
                    //log the exception
                }
            }
        }

        try {


                Log.e("RESULT CODE", "OK");
            try {

                ContentValues contentValues = new ContentValues();
                String line = "";
                db.beginTransaction();

                while ((line = buffer.readLine()) != null) {

                    Log.e("line", line);
                    String[] str = line.split(",", 7); // defining 3 columns with null or blank field //values acceptance

//Id, Company,Name,Price

                    String date = str[0].toString();
                    String open = str[1].toString();
                    String close = str[2].toString();
                    String high = str[2].toString();
                    String low = str[2].toString();
                    String volume = str[2].toString();
                    String adj_close = str[2].toString();

                    contentValues.put(Utils.Date, date);
                    contentValues.put(Utils.Open, open);
                    contentValues.put(Utils.Close, close);
                    contentValues.put(Utils.High, high);
                    contentValues.put(Utils.Low, low);
                    contentValues.put(Utils.Volume, volume);
                    contentValues.put(Utils.Adj_Close, adj_close);
                    db.insert(Utils.Table_name, null, contentValues);


                }
                db.setTransactionSuccessful();

                db.endTransaction();

            } catch (SQLException e) {
                Log.e("SQLError", e.getMessage().toString());
            } catch (IOException e) {
                Log.e("IOException", e.getMessage().toString());

            }

        } catch (Exception ex) {
            Log.e("Error", ex.getMessage().toString());
            if (db.inTransaction())

                db.endTransaction();

            Toast.makeText(DataActivity.this, ex.getMessage(), Toast.LENGTH_LONG).show();



            Stocks x = new Stocks();
            myList=controller.getAllStocks();
            for (Stocks stocks : myList){
                x=stocks;
                Log.d("tagg", "onCreate: "+stocks.getDate()+"\n");
            }

            final Stocks finalX2 = x;
            mspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //    date.setText(finalX2.getDate());

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });


        }
    }
        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            getMenuInflater().inflate(R.menu.menu, menu);
            return super.onCreateOptionsMenu(menu);
        }

        @Override
        public boolean onOptionsItemSelected (@NonNull MenuItem item){
            switch (item.getItemId()) {

                case R.id.sign_out:
                    if (user != null && firebaseAuth != null) {
                        firebaseAuth.signOut();

                        startActivity(new Intent(DataActivity.this, MainActivity.class));
                    }
                    break;
            }
            return super.onOptionsItemSelected(item);
        }
    }
