package com.rajaprasath.stockerz;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import utils.StockerApi;


public class Login_Activity extends AppCompatActivity {

    private Button login, create_account,google_signin;
    private AutoCompleteTextView email;
    private EditText password;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private FirebaseUser user;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("Users");
    private GoogleSignInClient mGoogleSignInClient;
    private int RC_SIGN_IN=999;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_);
        login = findViewById(R.id.login);
        create_account = findViewById(R.id.create_account);
        SignInButton googlesignin = findViewById(R.id.sign_in_button);
        googlesignin.setSize(SignInButton.SIZE_STANDARD);
        email = findViewById(R.id._email);
        password = findViewById(R.id._password);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        create_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login_Activity.this, CreateAccountActivity.class));
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Log.d("email", "onClick: " + email.getText().toString().trim());
                String emailid = email.getText().toString().trim();
                String pwd = password.getText().toString().trim();
                loginwithEmailAndPassword(emailid, pwd);
            }
        });
      googlesignin.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
             signIn();
          }
      });
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);

                firebaseAuthWithGoogle(account.getIdToken());
            } catch (ApiException e) {

            }
        }
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        firebaseAuth=FirebaseAuth.getInstance();
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            
                            FirebaseUser user = firebaseAuth.getCurrentUser();
                            assert user != null;
                            String currentuserid= user.getUid();
                            collectionReference.whereEqualTo("userid",currentuserid).addSnapshotListener(new EventListener<QuerySnapshot>() {
                                @Override
                                public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                                    assert queryDocumentSnapshots != null;
                                    if(!queryDocumentSnapshots.isEmpty()){
                                        for(QueryDocumentSnapshot snapshots : queryDocumentSnapshots){
                                            StockerApi.getInstance().setUsername(snapshots.getString("username"));
                                            StockerApi.getInstance().setUserid(snapshots.getString("userid"));
                                            startActivity(new Intent(Login_Activity.this,DataActivity.class));
                                            finish();

                                        }

                                    }
                                }
                            });

                        } else {
                            // If sign in fails, display a message to the user.

                        }

                        // ...
                    }
                });
    }



    private void loginwithEmailAndPassword(String email, String password) {
        if(!TextUtils.isEmpty(email)&&!TextUtils.isEmpty(password)){
            Log.d("email", "loginwithEmailAndPassword: "+email+"  "+password);
            firebaseAuth=FirebaseAuth.getInstance();
            firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {

                    FirebaseUser user =firebaseAuth.getCurrentUser();
                    assert user != null;
                    String currentuserid= user.getUid();
                    collectionReference.whereEqualTo("userid",currentuserid).addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                            assert queryDocumentSnapshots != null;
                            if(!queryDocumentSnapshots.isEmpty()){
                                for(QueryDocumentSnapshot snapshots : queryDocumentSnapshots){
                                    StockerApi.getInstance().setUsername(snapshots.getString("username"));
                                    StockerApi.getInstance().setUserid(snapshots.getString("userid"));
                                    startActivity(new Intent(Login_Activity.this,DataActivity.class));
                                    finish();

                                }

                            }
                        }
                    });


                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });



        }


    }


}


