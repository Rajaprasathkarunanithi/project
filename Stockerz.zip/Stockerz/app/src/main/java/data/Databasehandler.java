package data;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.Contacts;
import android.provider.ContactsContract;
import android.util.Log;

import com.rajaprasath.stockerz.R;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import model.Stocks;
import utils.Utils;

import static utils.Utils.Database_name;
import static utils.Utils.Table_name;

public class Databasehandler extends SQLiteOpenHelper {
    public Databasehandler( Context context) {
        super(context, Database_name, null , Utils.Database_version);

    }
    private static final String LOGCAT = null;



    @Override
    public void onCreate(SQLiteDatabase database) {
       // PRIMARY KEY
        String query;

        query = "CREATE TABLE IF NOT EXISTS " + Table_name + "( " + Utils.Date + " TEXT PRIMARY KEY, " +
                Utils.Open + " TEXT, " + Utils.Close +
                " TEXT, " +Utils.High + " TEXT, " +Utils.Low + " TEXT, " +Utils.Volume + " TEXT, "
                +Utils.Adj_Close + " TEXT)";
        Log.e("create Query", query);
        database.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old, int current_version) {
        String query;
        query = "DROP TABLE IF EXISTS " + Table_name;
        database.execSQL(query);
        onCreate(database);
    }

    public List<Stocks> getAllStocks() {

        List<Stocks> stocksList;
        stocksList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + Table_name;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {

            do {
//Id, Company,Name,Price
                Stocks stocks= new Stocks();
                stocks.setDate(cursor.getString(0));
                stocks.setOpen(cursor.getString(1));
                stocks.setHigh(cursor.getString(2));
                stocks.setLow(cursor.getString(3));
                stocks.setClose(cursor.getString(4));
                stocks.setAdj_Close(cursor.getString(5));
                stocks.setVolume(cursor.getString(6));
                stocksList.add(stocks);
                Log.e("dataofList", cursor.getString(0) + "," + cursor.getString(1) + "," + cursor.getString(2));
            } while (cursor.moveToNext());
        }
        return stocksList;

    }

}