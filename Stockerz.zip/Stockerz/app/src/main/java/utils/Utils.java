package utils;

public class Utils {
    public static final int Database_version=1;
    public static final String Database_name="stocker_db";
    public static final String Table_name="stock_table";

    public static final String Date="Date";
    public static final String Open="Open";
    public static final String High="High";
    public static final String Low="Low";
    public static final String Close="Close";
    public static final String Adj_Close="Adj_Close";
    public static final String Volume="Volume";
}
